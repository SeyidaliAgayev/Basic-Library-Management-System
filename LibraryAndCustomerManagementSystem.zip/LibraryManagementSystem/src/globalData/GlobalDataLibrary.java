package globalData;

import model.Library;

public class GlobalDataLibrary {
    public static Library[] libraries;
}
