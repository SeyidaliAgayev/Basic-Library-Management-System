package globalData;
import model.Customer;

public class GlobalDataCustomer {
    public static Customer[] customers;
}
