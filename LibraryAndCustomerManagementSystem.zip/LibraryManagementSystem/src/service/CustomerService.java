package service;

public interface CustomerService {
    boolean signUp();
    void logIn();
    void rentBook();
    boolean updateCustomer();
    boolean deleteCustomer();
    void searchCustomer();
    void showCustomer();
}
