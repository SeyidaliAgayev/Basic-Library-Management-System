package service;

public interface LibraryService {
    void register();
    void show();
    void search();
    boolean update();
    boolean delete();
    void carryToStock();

}
