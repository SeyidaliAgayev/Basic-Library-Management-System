package service;

public interface LibraryManagementService {
    void libraryManagement();
}
