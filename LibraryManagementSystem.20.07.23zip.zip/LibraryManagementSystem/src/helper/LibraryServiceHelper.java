package helper;


import enums.ExceptionEnum;
import exception.BookNotFound;
import globalData.GlobalData;
import model.Library;
import static util.InputUtil.*;

public class LibraryServiceHelper {
    static int bookCount = 0;
    private static int id = 0;

    public static Library fillLibrary(){
        String name = stringInput("Enter the book name: ");
        String author = stringInput("Enter the author name: ");
        String genre = stringInput("Enter the genre: ");
        int pageCount = intInput("Enter the page count: ");
        String language = stringInput("Enter the language: ");
        int price = intInput("Enter the price: ");
        int count = intInput("Enter the count of book: ");
        byte stockStatus = byteInput("Enter stock status(if book is in stock, status will be 1 and vice versa): ");

        return new Library(++id,name,author,genre,pageCount,language,price,count,stockStatus);
    }

    public static void registerHelper() {
        Library library =fillLibrary();
        if (library != null) {
            GlobalData.libraries[bookCount] = library;
            bookCount++;
        }
    }

    public static Library findById(int id) {
        Library library = new Library();
        if (GlobalData.libraries == null) {
            throw new BookNotFound(ExceptionEnum.BOOK_NOT_FOUND);
        } else {
            for (int i = 0; i < GlobalData.libraries.length; i++) {
                if (GlobalData.libraries[i].getId() == id) {
                    library = GlobalData.libraries[i];
                    break;
                }
            }
        }
        return library;
    }
}
