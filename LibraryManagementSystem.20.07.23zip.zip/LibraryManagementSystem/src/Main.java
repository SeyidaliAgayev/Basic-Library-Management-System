import service.LibraryManagementService;
import service.impl.ILibraryManagementService;

public class Main {
    public static void main(String[] args) {
        LibraryManagementService libraryManagementService = new ILibraryManagementService();
        libraryManagementService.management();
    }
}