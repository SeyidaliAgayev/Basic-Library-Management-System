package service;

public interface LibraryManagementService {
    void management();
}
