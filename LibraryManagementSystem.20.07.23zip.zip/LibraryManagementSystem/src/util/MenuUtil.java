package util;
import static util.InputUtil.*;
public class MenuUtil {
    public static byte entryMenu() {
        System.out.println("""
                        ----------------Library Management System----------------
                        [0].Finish Program!
                        [1].Register Book
                        [2].Show Book
                        [3].Update Book
                        [4].Delete Book
                        [5].Search Book
                        [6].Carry to Stock
                        --------------------------------------------------------
                        """
        );
        return byteInput("Choose an option: ");
    }

    public static byte entryShow() {
        System.out.println(
                """
                ------------------
                [1].Storage
                [2].Stocks   
                ------------------
                """
        );
        return byteInput("Choose an option: ");
    }

    public static String entryDetail() {
        System.out.println("Detailed information of book! ");
        return stringInput("Enter the book name: ");
    }

    public static byte entrySearch() {
        System.out.println(
                 """
                 [1].Name
                 [2].Author
                 [3].Genre
                 """);
        return byteInput("Choose an option to search: ");
    }
}
