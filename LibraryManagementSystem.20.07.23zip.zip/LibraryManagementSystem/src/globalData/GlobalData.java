package globalData;

import model.Library;

public class GlobalData {
    public static Library[] libraries;
}
