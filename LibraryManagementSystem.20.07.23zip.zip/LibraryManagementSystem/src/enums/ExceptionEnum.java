package enums;

public enum ExceptionEnum {
    WRONG_FORMAT("Wrong Format"),
    BOOK_NOT_FOUND("Book not found"),
    INVALID_OPTION("Invalid option"),
    EMPTY_LIST("Empty list");

    private String message;

    ExceptionEnum(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
